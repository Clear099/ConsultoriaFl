const express = require('express');
const path = require('path');
const morgan = require('morgan');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const myConnection = require('express-myconnection');
const multer = require('multer');
const app = express();


app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'lukas3'
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads/')
  },
  filename: (req, file, cb) => {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
  }
});

const upload = multer({ storage: storage });

async function saveToDatabase(filePath, description) {
  try {
      const query = 'INSERT INTO consultoria (documento, consultoria) VALUES (?, ?)';
      await connection.query(query, [filePath, description]);
  } catch (error) {
      console.error(error);
      throw error;  // Aquí rechazamos la promesa si hay un error
  }
}


app.post('/uploadFile', upload.single('fileUpload'), (req, res) => {
  let file = req.file;
  let description = req.body.description;

  let filePath = './uploads/' + file.filename; // Asumimos que el archivo se guarda en './uploads/'

  saveToDatabase(filePath, description)
    .then(() => {
      res.send(`
        <html>
          <body>
            <p>Archivo subido y descripción guardada con éxito!</p>
            <button onclick="location.href='/menu.html'" type="button">
              Volver al menú principal
            </button>
          </body>
        </html>
      `);
    })
    .catch(error => {
      console.error(error);
      res.status(500).send('Hubo un error al guardar el archivo y la descripción en la base de datos.');
    });
});

app.set('port', process.env.PORT || 3000);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(morgan('dev'));
app.use(myConnection(mysql, {
  host: 'localhost',
  user: 'root',
  password: '',
  port: 3306,
  database: 'lukas3'
}, 'single'));

app.use(express.static(path.join(__dirname, 'public')));

app.listen(app.get('port'), () => {
  console.log('Server on port 3000');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const query = `SELECT * FROM usuario WHERE nombre = ? AND contrasena = ?`;
  connection.query(query, [username, password], (error, results, fields) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }
    if (results.length === 0) {
      return res.status(401).send(`
        <html>
          <body>
            <p>Credenciales incorrectas</p>
            <button onclick="location.href='/index.html'" type="button">
              Volver al inicio
            </button>
          </body>
        </html>
      `);
    }

    const id_tipo_usuario = results[0].id_tipo_usuario;

    if (id_tipo_usuario === 1) {
      res.redirect('/menu.html');
    } else if (id_tipo_usuario === 2) {
      res.redirect('/consultor.html');
    } else if (id_tipo_usuario === 3) {
      res.redirect('/menuadmin.html');
    } else {
      res.status(401).send(`
        <html>
          <body>
            <p>Tipo de usuario no válido</p>
            <button onclick="location.href='/index.html'" type="button">
              Volver al inicio
            </button>
          </body>
        </html>
      `);
    }
  });
});

app.post('/register', (req, res) => {
  const { nombre, rut, correo, contrasena, id_tipo_usuario } = req.body;

  if (!nombre || !contrasena) {
    return res.status(400).send(`
      <html>
        <body>
          <p>El nombre y contraseña son campos obligatorios</p>
          <button onclick="location.href='/register.html'" type="button">
            Volver al registro de usuario
          </button>
        </body>
      </html>
    `);
  }

  const query = `INSERT INTO usuario (nombre, rut, correo, contrasena, id_tipo_usuario) VALUES (?, ?, ?, ?, ?)`;

  connection.query(query, [nombre, rut, correo, contrasena, id_tipo_usuario], (error, results, fields) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    return res.redirect('/index.html');
  });
});

// Ruta para mostrar y editar usuarios
app.get('/usuario/:id_usuario', function(req, res) {
  let id_usuario = req.params.id;
  
  const query = 'SELECT * FROM usuario WHERE id_usuario = ?';
  connection.query(query, [id_usuario], (error, results, fields) => {
      if (error) {
          console.error(error);
          return res.status(500).send('Error en el servidor');
      }
      
      if (results.length === 0) {
          return res.status(404).send('Usuario no encontrado');
      }
      
      res.json(results[0]);
  });
});

// Ruta para guardar los cambios en la columna id_tipo_usuario
app.post('/edit', (req, res) => {
  const { id_usuario, id_tipo_usuario } = req.body;

  const query = 'UPDATE usuario SET id_tipo_usuario = ? WHERE id_usuario = ?';
  connection.query(query, [id_tipo_usuario, id_usuario], (error, results) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.send('Usuario actualizado con éxito');
  });
});
app.post('/delete', (req, res) => {
  const { id_usuario } = req.body;

  const query = 'DELETE FROM usuario WHERE id_usuario = ?';
  connection.query(query, [id_usuario], (error, results) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
      
    }

    res.send('Usuario eliminado con éxito');
  });
});
