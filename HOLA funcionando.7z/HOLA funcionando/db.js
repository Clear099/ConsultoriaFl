const sql = require('mssql');
const util = require('util');



const mysql = require("mysql");
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password:'',
    database: 'lukas3'
});

connection.query = util.promisify(connection.query);

async function saveToDatabase(filePath, description) {
    try {
        const query = 'INSERT INTO consultoria (documento, consultoria) VALUES (?, ?)';
        await connection.query(query, [filePath, description]);
    } catch (error) {
        console.error(error);
        throw error;  // Aquí rechazamos la promesa si hay un error
    }
}

module.exports = { saveToDatabase };

conn.connect(function (err){
    if(err){
        console.log(err);
        return;
    }
    else{
        console.log("La base de datos se ha conectado exitosamente");
        
    }
});

module.exports = conn;
conn.query("SELECT * FROM USUARIO",(err,resp)=>{
    console.log(resp);

})


module.exports = conn;
