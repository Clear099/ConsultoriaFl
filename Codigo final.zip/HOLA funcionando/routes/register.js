app.post('/register', (req, res) => {
    const { nombre, rut, correo, contrasena, id_tipo_usuario } = req.body;

    // Consulta SQL para insertar el nuevo usuario en la base de datos
    const query = `INSERT INTO usuario (nombre, rut, correo, contrasena, id_tipo_usuario) VALUES (?, ?, ?, ?, ?)`;

    connection.query(query, [nombre, rut, correo, contrasena, id_tipo_usuario], (error, results, fields) => {
      if (error) {
        console.error(error);
        return res.status(500).send('Error en el servidor');
      }
      
      // Registro exitoso
      return res.status(201).send('Registro exitoso');
    });
});
