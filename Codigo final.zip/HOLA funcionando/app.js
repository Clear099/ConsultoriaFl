const express = require('express');
const path = require('path');
const morgan = require('morgan');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const myConnection = require('express-myconnection');
const multer = require('multer');
const app = express();

app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'lukas3'
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, './uploads/')
  },
  filename: (req, file, cb) => {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname))
  }
});

const upload = multer({ storage: storage });

async function saveToDatabase(filePath, description) {
  try {
    const query = 'INSERT INTO consultoria (documento, consultoria) VALUES (?, ?)';
    await connection.query(query, [filePath, description]);
  } catch (error) {
    console.error(error);
    throw error;
  }
}

app.post('/uploadFile', upload.single('fileUpload'), (req, res) => {
  let file = req.file;
  let description = req.body.description;

  let filePath = './uploads/' + file.filename;

  saveToDatabase(filePath, description)
    .then(() => {
      res.send(`
        <html>
          <body>
            <p>Archivo subido y descripción guardada con éxito!</p>
            <button onclick="location.href='/menu.html'" type="button">
              Volver al menú principal
            </button>
          </body>
        </html>
      `);
    })
    .catch(error => {
      console.error(error);
      res.status(500).send('Hubo un error al guardar el archivo y la descripción en la base de datos.');
    });
});

app.set('port', process.env.PORT || 3000);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(morgan('dev'));
app.use(myConnection(mysql, {
  host: 'localhost',
  user: 'root',
  password: '',
  port: 3306,
  database: 'lukas3'
}, 'single'));

app.use(express.static(path.join(__dirname, 'public')));

app.listen(app.get('port'), () => {
  console.log('Server on port 3000');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const query = `SELECT * FROM usuario WHERE nombre = ? AND contrasena = ?`;
  connection.query(query, [username, password], (error, results, fields) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }
    if (results.length === 0) {
      return res.status(401).send(`
        <html>
          <body>
            <p>Credenciales incorrectas</p>
            <button onclick="location.href='/index.html'" type="button">
              Volver al inicio
            </button>
          </body>
        </html>
      `);
    }

    const id_tipo_usuario = results[0].id_tipo_usuario;

    if (id_tipo_usuario === 1) {
      res.redirect('/menu.html');
    } else if (id_tipo_usuario === 2) {
      res.redirect('/consultor.html');
    } else if (id_tipo_usuario === 3) {
      res.redirect('/menuadmin.html');
    } else {
      res.status(401).send(`
        <html>
          <body>
            <p>Tipo de usuario no válido</p>
            <button onclick="location.href='/index.html'" type="button">
              Volver al inicio
            </button>
          </body>
        </html>
      `);
    }
  });
});

app.post('/register', (req, res) => {
  const { nombre, rut, correo, contrasena, id_tipo_usuario } = req.body;

  if (!nombre || !contrasena) {
    return res.status(400).send(`
      <html>
        <body>
          <p>El nombre y contraseña son campos obligatorios</p>
          <button onclick="location.href='/register.html'" type="button">
            Volver al registro de usuario
          </button>
        </body>
      </html>
    `);
  }

  const query = `INSERT INTO usuario (nombre, rut, correo, contrasena, id_tipo_usuario) VALUES (?, ?, ?, ?, ?)`;

  connection.query(query, [nombre, rut, correo, contrasena, id_tipo_usuario], (error, results, fields) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    return res.redirect('/index.html');
  });
});

// Ruta para mostrar la página admin.html
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Ruta para obtener todos los usuarios
app.get('/users', (req, res) => {
  const query = 'SELECT * FROM usuario';
  connection.query(query, (error, results, fields) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.json(results);
  });
});

// Ruta para obtener un usuario específico por su ID
app.get('/users/:id', (req, res) => {
  const id_usuario = req.params.id;

  const query = 'SELECT * FROM usuario WHERE id_usuario = ?';
  connection.query(query, [id_usuario], (error, results, fields) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    if (results.length === 0) {
      return res.status(404).send('Usuario no encontrado');
    }

    res.json(results[0]);
  });
});

// Ruta para editar un usuario
app.post('/edit', (req, res) => {
  const { id_usuario, id_tipo_usuario } = req.body;

  const query = 'UPDATE usuario SET id_tipo_usuario = ? WHERE id_usuario = ?';
  connection.query(query, [id_tipo_usuario, id_usuario], (error, results) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.send('Usuario actualizado con éxito');
  });
});

// Ruta para eliminar un usuario
app.post('/delete', (req, res) => {
  const { id_usuario } = req.body;

  const query = 'DELETE FROM usuario WHERE id_usuario = ?';
  connection.query(query, [id_usuario], (error, results) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.send('Usuario eliminado con éxito');
  });

});

app.post('/add', (req, res) => {
  const { nombre, rut, correo, id_tipo_usuario } = req.body;
  const newUser = { nombre, rut, correo, id_tipo_usuario };
  connection.query('INSERT INTO usuario SET ?', newUser, (err, result) => {
    if (err) {
      throw err;
    }
    console.log('Usuario agregado correctamente');
    res.redirect('/');
  });
});

// Ruta para agregar una empresa mediante un formulario
app.post('/addEmpresa', (req, res) => {
  const { nombre, direccion, numero, rut_empresa, ciudad } = req.body;
  const newEmpresa = { nombre, direccion, numero, rut_empresa, ciudad };
  connection.query('INSERT INTO empresa SET ?', newEmpresa, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error en el servidor');
    }
    console.log('Empresa agregada correctamente');
    res.send(`
      <html>
        <body>
          <p>Empresa agregada con éxito</p>
          <button onclick="location.href='/menu.html'" type="button">
            Volver al menú principal
          </button>
        </body>
      </html>
    `);
  });
});

// Ruta para editar una empresa
app.post('/editEmpresa', (req, res) => {
  const { id_empresa, nombre, direccion, numero, rut_empresa, ciudad } = req.body;

  const query = 'UPDATE empresa SET nombre = ?, direccion = ?, numero = ?, rut_empresa = ?, ciudad = ? WHERE id_empresa = ?';
  connection.query(query, [nombre, direccion, numero, rut_empresa, ciudad, id_empresa], (error, results) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.send('Empresa actualizada con éxito');
  });
});

// Ruta para eliminar una empresa
app.post('/deleteEmpresa', (req, res) => {
  const { id_empresa } = req.body;

  const query = 'DELETE FROM empresa WHERE id_empresa = ?';
  connection.query(query, [id_empresa], (error, results) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.send('Empresa eliminada con éxito');
  });
});

// Ruta para obtener todas las empresas
app.get('/empresas', (req, res) => {
  const query = 'SELECT * FROM empresa';
  connection.query(query, (error, results, fields) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.json(results);
  });
});

// Ruta para obtener el historial de archivos subidos por el alumno
app.get('/fileHistory/:id_usuario', (req, res) => {
  const id_usuario = req.params.id_usuario;

  const query = 'SELECT * FROM consultoria WHERE id_usuario = ?';
  connection.query(query, [id_usuario], (error, results, fields) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.render('fileHistory', { files: results });
  });
});

// Ruta para agregar una consultoria mediante un formulario
app.post('/addConsultoria', (req, res) => {
  const { consultoria, fecha_subida, estado, notas } = req.body;
  const newConsultoria = { consultoria, fecha_subida, estado, notas };
  connection.query('INSERT INTO consultoria SET ?', newConsultoria, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Error en el servidor');
    }
    console.log('Consultoria agregada correctamente');
    res.send(`
      <html>
        <body>
          <p>Consultoria agregada con éxito</p>
          <button onclick="location.href='/menu.html'" type="button">
            Volver al menú principal
          </button>
        </body>
      </html>
    `);
  });
});

// Ruta para editar una consultoria
app.post('/editConsultoria', (req, res) => {
  const { id_consultoria, consultoria, fecha_subida, estado, notas } = req.body;

  const query = 'UPDATE consultoria SET consultoria = ?, fecha_subida = ?, estado = ?, notas = ? WHERE id_consultoria = ?';
  connection.query(query, [consultoria, fecha_subida, estado, notas, id_consultoria], (error, results) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.send('Consultoria actualizada con éxito');
  });
});

// Ruta para eliminar una consultoria
app.post('/deleteConsultoria', (req, res) => {
  const { id_consultoria } = req.body;

  const query = 'DELETE FROM consultoria WHERE id_consultoria = ?';
  connection.query(query, [id_consultoria], (error, results) => {
    if (error) {
      console.error(error);
      return res.status(500).send('Error en el servidor');
    }

    res.send('Consultoria eliminada con éxito');
  });
});