<?php
// Conexión a la base de datos
$conexion = new mysqli('localhost', 'root', '', 'lukas3');

if ($conexion->connect_error) {
    die("La conexión a la base de datos ha fallado: " . $conexion->connect_error);
}

// Consulta para obtener el nombre de usuario
$sql = "SELECT nombre FROM usuario WHERE nombre = '" . $_SESSION['nombre'] . "'";
$resultado = $conexion->query($sql);

if ($resultado->num_rows > 0) {
    // Imprimir el nombre de usuario
    while($row = $resultado->fetch_assoc()) {
        echo $row["nombre"];
    }
} else {
    echo "No se encontraron resultados";
}
$conexion->close();
?>
